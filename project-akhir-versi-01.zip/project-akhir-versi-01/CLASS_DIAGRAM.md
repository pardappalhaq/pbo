# DOKUMENTASI UML CLASS DIAGRAM - APLIKASI KLIK (VERSI 01 - UPDATED)
**Mata Kuliah:** Pemrograman Berorientasi Objek  
**Program Studi:** Teknologi Rekayasa Perangkat Lunak - Institut Pertanian Bogor  
**Domain Sistem:** *Klik* (Platform Pencarian Partner Olahraga & Pemesanan Lapangan)

---

## 1. Visualisasi Diagram Kelas

![UML Class Diagram Aplikasi Klik](class_diagram.png)

### Diagram Mermaid (Interaktif)
```mermaid
classDiagram
    direction TB

    %% INTERFACES
    class MatchingService {
        <<interface>>
        +cariPartner() void
        +lihatProfilPartner() void
    }

    class BookingService {
        <<interface>>
        +cekJadwalLapangan() void
        +bookingLapangan() void
    }

    %% ABSTRACT CLASS
    class PartnerOlahraga {
        <<abstract>>
        #String nama
        #int usia
        #String lokasi
        #int frekuensiOlahraga
        +tampilkanProfil()* void
        +hitungKecocokan()* void
        +tampilkanStatus() void
        +getNama() String
        +getUsia() int
        +getLokasi() String
        +getFrekuensiOlahraga() int
    }

    %% SUBCLASSES (INHERITANCE)
    class PartnerBasket {
        +PartnerBasket(String nama, int usia, String lokasi, int frekuensiOlahraga)
        +tampilkanProfil() void
        +hitungKecocokan() void
        +tentukanPosisiBasket() void
    }

    class PartnerFutsal {
        +PartnerFutsal(String nama, int usia, String lokasi, int frekuensiOlahraga)
        +tampilkanProfil() void
        +hitungKecocokan() void
        +pilihModeFutsal() void
    }

    %% CONTROLLER & SERVICES
    class PencariPartner {
        -List~PartnerOlahraga~ daftarPartner
        +PencariPartner()
        +tambahPartner(PartnerOlahraga partner) void
        +getDaftarPartner() List~PartnerOlahraga~
        +cariPartner() void
        +lihatProfilPartner() void
    }

    class MitraLapangan {
        -String namaMitra
        -String lokasi
        -List~JadwalLapangan~ daftarJadwal
        +MitraLapangan()
        +MitraLapangan(String namaMitra, String lokasi)
        +tambahJadwal(String idJadwal, String hari, String jam, double harga) void
        +cekJadwalLapangan() void
        +bookingLapangan() void
        +getNamaMitra() String
        +getLokasi() String
        +getDaftarJadwal() List~JadwalLapangan~
    }

    %% COMPOSED ENTITIES
    class JadwalLapangan {
        -String idJadwal
        -String hari
        -String jam
        -double harga
        -boolean isTersedia
        +JadwalLapangan(String idJadwal, String hari, String jam, double harga)
        +tampilkanJadwal() void
        +setTersedia(boolean tersedia) void
        +isTersedia() boolean
        +getIdJadwal() String
        +getHari() String
        +getJam() String
        +getHarga() double
    }

    class ProfilPengguna {
        -String idPengguna
        -String bio
        -String noTelepon
        +ProfilPengguna(String idPengguna, String bio, String noTelepon)
        +tampilkanProfil() void
        +getIdPengguna() String
        +getBio() String
        +getNoTelepon() String
    }

    %% MAIN USER ENTITY
    class PenggunaKlik {
        -String nama
        -ProfilPengguna profil
        -List~MitraLapangan~ mitraLangganan
        +PenggunaKlik(String nama)
        +PenggunaKlik(String nama, String idPengguna, String bio, String noTelepon)
        +hubungkanMitra(MitraLapangan mitra) void
        +getNama() String
        +getProfil() ProfilPengguna
        +getMitraLangganan() List~MitraLapangan~
        +cariPartner() void
        +lihatProfilPartner() void
        +cekJadwalLapangan() void
        +bookingLapangan() void
    }

    %% =======================
    %% RELASI & MULTIPLISITAS
    %% =======================

    %% 1. Generalisasi (Inheritance / Extends)
    PartnerOlahraga <|-- PartnerBasket : mewarisi (extends)
    PartnerOlahraga <|-- PartnerFutsal : mewarisi (extends)

    %% 2. Realisasi (Interface Realization / Implements)
    MatchingService <|.. PencariPartner : mengimplementasikan
    BookingService <|.. MitraLapangan : mengimplementasikan
    MatchingService <|.. PenggunaKlik : mengimplementasikan
    BookingService <|.. PenggunaKlik : mengimplementasikan

    %% 3. Agregasi (Aggregation / Loose Whole-Part)
    PencariPartner "1" o-- "0..*" PartnerOlahraga : mengagregasi daftar partner

    %% 4. Komposisi (Composition / Strong Whole-Part)
    MitraLapangan "1" *-- "1..*" JadwalLapangan : mengelola jadwal eksklusif
    PenggunaKlik "1" *-- "1" ProfilPengguna : memiliki akun profil internal

    %% 5. Asosiasi (Association / Uses-a)
    PenggunaKlik "1..*" --> "0..*" MitraLapangan : memesan / booking lapangan
    PenggunaKlik "1" --> "0..*" PartnerOlahraga : terhubung / bertanding dengan
```

---

## 2. Tabel Analisis Relasi dan Multiplisitas

| Kelas Sumber | Multiplisitas | Jenis Relasi | Notasi UML | Multiplisitas | Kelas Tujuan | Deskripsi Relasi & Karakteristik Lifecycle |
| :--- | :---: | :--- | :---: | :---: | :--- | :--- |
| **PartnerBasket** | - | **Generalisasi** *(Inheritance)* | `──▷` | - | **PartnerOlahraga** | Subclass mewarisi atribut nama, usia, lokasi, frekuensi, serta meng-override method abstract. |
| **PartnerFutsal** | - | **Generalisasi** *(Inheritance)* | `──▷` | - | **PartnerOlahraga** | Subclass mewarisi seluruh anggota `PartnerOlahraga` dan menambahkan method khusus futsal. |
| **PencariPartner** | - | **Realisasi** *(Realization)* | `..▷` | - | **MatchingService** | Mengimplementasikan kontrak method `cariPartner()` dan `lihatProfilPartner()`. |
| **MitraLapangan** | - | **Realisasi** *(Realization)* | `..▷` | - | **BookingService** | Mengimplementasikan kontrak method `cekJadwalLapangan()` dan `bookingLapangan()`. |
| **PenggunaKlik** | - | **Realisasi Ganda** | `..▷` | - | **MatchingService, BookingService** | `PenggunaKlik` mengimplementasikan kedua antarmuka layanan utama sekaligus. |
| **PencariPartner** | `1` | **Agregasi** *(Aggregation)* | `◇──` | `0..*` | **PartnerOlahraga** | **Loose Whole-Part:** `PencariPartner` menampung kumpulan partner olahraga. Objek partner dibuat secara independen dan tetap hidup meskipun objek pencarian di-reset. |
| **MitraLapangan** | `1` | **Komposisi** *(Composition)* | `◆──` | `1..*` | **JadwalLapangan** | **Strong Whole-Part:** Setiap slot jadwal diciptakan di dalam `MitraLapangan` dan terikat penuh pada mitra tersebut. Jika mitra dihapus, seluruh jadwalnya ikut musnah. |
| **PenggunaKlik** | `1` | **Komposisi** *(Composition)* | `◆──` | `1` | **ProfilPengguna** | **Strong Whole-Part:** Setiap akun pengguna memiliki 1 profil internal yang diciptakan saat registrasi `PenggunaKlik` dan tidak eksis tanpa pengguna. |
| **PenggunaKlik** | `1..*` | **Asosiasi** *(Association)* | `──>` | `0..*` | **MitraLapangan** | Hubungan struktural interaksi transaksi pemesanan lapangan antara pengguna dan mitra. |
| **PenggunaKlik** | `1` | **Asosiasi** *(Association)* | `──>` | `0..*` | **PartnerOlahraga** | Pengguna berinteraksi dan mencocokkan diri dengan kandidat partner olahraga. |

---

## 3. Penjelasan Rinci 5 Jenis Relasi Berorientasi Objek

### 1. Generalisasi (Generalization / Inheritance)
- **Simbol:** Garis solid dengan panah segitiga kosong (`<|--`).
- **Implementasi Java:** Kata kunci `extends`.
- **Analisis:**
  - `PartnerOlahraga` bertindak sebagai *abstract class* (induk) yang membungkus atribut bersama (`nama`, `usia`, `lokasi`, `frekuensiOlahraga`) dan dua method abstract: `tampilkanProfil()` dan `hitungKecocokan()`.
  - `PartnerBasket` dan `PartnerFutsal` merupakan kelas turunan konkrit yang meng-override kedua method abstract tersebut sesuai karakteristik cabang olahraganya, sekaligus menambahkan method khusus masing-masing (`tentukanPosisiBasket()` dan `pilihModeFutsal()`).

### 2. Realisasi (Realization / Interface Implementation)
- **Simbol:** Garis putus-putus dengan panah segitiga kosong (`<|..`).
- **Implementasi Java:** Kata kunci `implements`.
- **Analisis:**
  - `MatchingService` dan `BookingService` merupakan kontrak perilaku sistem Klik.
  - `PencariPartner` mengimplementasikan `MatchingService`.
  - `MitraLapangan` mengimplementasikan `BookingService`.
  - `PenggunaKlik` mengimplementasikan `MatchingService` dan `BookingService` (*multiple interface implementation*), menunjukkan bahwa pengguna berinteraksi dengan kedua pilar fungsionalitas aplikasi Klik.

### 3. Asosiasi (Association)
- **Simbol:** Garis berpanah terbuka arah navigasi (`-->`) atau garis lurus (`--`).
- **Multiplisitas:** `1..*` ke `0..*`
- **Analisis:**
  - Asosiasi menggambarkan interaksi dua entitas yang memiliki siklus hidup independen dan tidak saling memiliki (*non-ownership relation*).
  - Objek `PenggunaKlik` memegang referensi ke objek `MitraLapangan` saat mencari tempat bermain dan mengeksekusi booking. Begitu pula mitra lapangan melayani banyak objek pengguna tanpa mengontrol siklus hidup objek pengguna tersebut.

### 4. Agregasi (Aggregation)
- **Simbol:** Garis berujung belah ketupat/wajik kosong (*hollow diamond*) `o--` pada kelas pemilik (*whole*).
- **Multiplisitas:** `1` (PencariPartner) ke `0..*` (PartnerOlahraga).
- **Karakteristik Lifecycle (Loose Coupling):**
  - Objek `PartnerOlahraga` (atlet futsal/basket) **diciptakan di luar** kelas `PencariPartner` dan dimasukkan melalui method `tambahPartner(PartnerOlahraga partner)`.
  - Jika objek `PencariPartner` dihancurkan atau di-reset, objek `PartnerOlahraga` **TIDAK ikut terhapus** dari memori sistem karena merupakan entitas mandiri yang dapat digunakan oleh modul lain.

### 5. Komposisi (Composition)
- **Simbol:** Garis berujung belah ketupat/wajik terisi penuh (*filled diamond*) `*--` pada kelas pemilik (*whole*).
- **Multiplisitas:**
  - `MitraLapangan` `1` *-- `1..*` `JadwalLapangan`
  - `PenggunaKlik` `1` *-- `1` `ProfilPengguna`
- **Karakteristik Lifecycle (Tight Coupling):**
  - Objek `JadwalLapangan` **diciptakan secara langsung di dalam konstruktor/metode** milik `MitraLapangan`.
  - Objek `JadwalLapangan` tidak memiliki arti dan tidak dapat berdiri sendiri tanpa adanya induk `MitraLapangan`. Jika suatu `MitraLapangan` dihapus dari sistem, seluruh `JadwalLapangan` miliknya **otomatis ikut terhapus**.
  - Hal yang sama berlaku pada `ProfilPengguna` yang diinisialisasi secara internal oleh `PenggunaKlik`.

---

## 4. Format PlantUML (Untuk Dokumen Word / PDF Laporan)

```plantuml
@startuml
skinparam classAttributeIconSize 0
skinparam monochrome false
skinparam roundcorner 5

interface MatchingService <<interface>> {
    + cariPartner() : void
    + lihatProfilPartner() : void
}

interface BookingService <<interface>> {
    + cekJadwalLapangan() : void
    + bookingLapangan() : void
}

abstract class PartnerOlahraga <<abstract>> {
    # nama : String
    # usia : int
    # lokasi : String
    # frekuensiOlahraga : int
    + {abstract} tampilkanProfil() : void
    + {abstract} hitungKecocokan() : void
    + tampilkanStatus() : void
    + getNama() : String
    + getUsia() : int
    + getLokasi() : String
    + getFrekuensiOlahraga() : int
}

class PartnerBasket {
    + PartnerBasket(nama: String, usia: int, lokasi: String, frekuensiOlahraga: int)
    + tampilkanProfil() : void
    + hitungKecocokan() : void
    + tentukanPosisiBasket() : void
}

class PartnerFutsal {
    + PartnerFutsal(nama: String, usia: int, lokasi: String, frekuensiOlahraga: int)
    + tampilkanProfil() : void
    + hitungKecocokan() : void
    + pilihModeFutsal() : void
}

class PencariPartner {
    - daftarPartner : List<PartnerOlahraga>
    + PencariPartner()
    + tambahPartner(partner: PartnerOlahraga) : void
    + getDaftarPartner() : List<PartnerOlahraga>
    + cariPartner() : void
    + lihatProfilPartner() : void
}

class MitraLapangan {
    - namaMitra : String
    - lokasi : String
    - daftarJadwal : List<JadwalLapangan>
    + MitraLapangan()
    + MitraLapangan(namaMitra: String, lokasi: String)
    + tambahJadwal(idJadwal: String, hari: String, jam: String, harga: double) : void
    + cekJadwalLapangan() : void
    + bookingLapangan() : void
    + getNamaMitra() : String
    + getLokasi() : String
    + getDaftarJadwal() : List<JadwalLapangan>
}

class JadwalLapangan {
    - idJadwal : String
    - hari : String
    - jam : String
    - harga : double
    - isTersedia : boolean
    + JadwalLapangan(idJadwal: String, hari: String, jam: String, harga: double)
    + tampilkanJadwal() : void
    + setTersedia(tersedia: boolean) : void
    + isTersedia() : boolean
    + getIdJadwal() : String
    + getHari() : String
    + getJam() : String
    + getHarga() : double
}

class ProfilPengguna {
    - idPengguna : String
    - bio : String
    - noTelepon : String
    + ProfilPengguna(idPengguna: String, bio: String, noTelepon: String)
    + tampilkanProfil() : void
    + getIdPengguna() : String
    + getBio() : String
    + getNoTelepon() : String
}

class PenggunaKlik {
    - nama : String
    - profil : ProfilPengguna
    - mitraLangganan : List<MitraLapangan>
    + PenggunaKlik(nama: String)
    + PenggunaKlik(nama: String, idPengguna: String, bio: String, noTelepon: String)
    + hubungkanMitra(mitra: MitraLapangan) : void
    + getNama() : String
    + getProfil() : ProfilPengguna
    + getMitraLangganan() : List<MitraLapangan>
    + cariPartner() : void
    + lihatProfilPartner() : void
    + cekJadwalLapangan() : void
    + bookingLapangan() : void
}

' 1. Generalisasi
PartnerOlahraga <|-- PartnerBasket
PartnerOlahraga <|-- PartnerFutsal

' 2. Realisasi
MatchingService <|.. PencariPartner
BookingService <|.. MitraLapangan
MatchingService <|.. PenggunaKlik
BookingService <|.. PenggunaKlik

' 3. Agregasi
PencariPartner "1" o-- "0..*" PartnerOlahraga : mengagregasi

' 4. Komposisi
MitraLapangan "1" *-- "1..*" JadwalLapangan : mengelola jadwal
PenggunaKlik "1" *-- "1" ProfilPengguna : memiliki profil

' 5. Asosiasi
PenggunaKlik "1..*" --> "0..*" MitraLapangan : memesan ke
PenggunaKlik "1" --> "0..*" PartnerOlahraga : berpartner dengan

@enduml
```
